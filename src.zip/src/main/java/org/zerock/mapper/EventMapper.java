package org.zerock.mapper;

import org.zerock.domain.EventVO;

public interface EventMapper {
	
	public void insert(EventVO event);

}
