package org.zerock.service;

import org.zerock.domain.EventVO;

public interface EventService {
	
	public void eventRegister(EventVO event);

}
